const express = require("express");
const app = express();

app.use(express.urlencoded({ extended: true }));
app.set("view engine", "ejs");

// Temporary server-side storage
let users = [];

app.get("/", (req, res) => {
    res.render("form", { message: null });
});

app.post("/register", (req, res) => {
    const { name, email } = req.body;

    // Server-side validation
    if (!name || !email) {
        return res.render("form", { message: "Invalid input data!" });
    }

    // Store validated data temporarily
    users.push({ name, email });

    res.render("form", { message: "Registration successful!" });
});

app.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});
