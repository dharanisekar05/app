const express = require("express");
const app = express();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));

// Set EJS as view engine
app.set("view engine", "ejs");

// Home route
app.get("/", (req, res) => {
    res.render("index", { name: null });
});

// Form submission route
app.post("/submit", (req, res) => {
    const userName = req.body.username;
    res.render("index", { name: userName });
});

// Start server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
