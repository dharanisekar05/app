function showSignup() {
  document.getElementById("signup").classList.remove("hidden");
  document.getElementById("login").classList.add("hidden");
}

function showLogin() {
  document.getElementById("login").classList.remove("hidden");
  document.getElementById("signup").classList.add("hidden");
}

// Toggle password visibility
function togglePassword(id) {
  const input = document.getElementById(id);
  input.type = input.type === "password" ? "text" : "password";
}

// SIGN UP
function signup() {
  const email = document.getElementById("signupEmail").value;
  const password = document.getElementById("signupPassword").value;
  const agree = document.getElementById("agree").checked;

  if (email === "" || password === "") {
    alert("Please fill all fields");
    return;
  }

  if (!agree) {
    alert("You must agree to the privacy policy");
    return;
  }

  // Save to local storage
  localStorage.setItem("email", email);
  localStorage.setItem("password", password);

  alert("Sign up successful! Now login.");
  showLogin();
}

// LOGIN
function login() {
  const loginEmail = document.getElementById("loginEmail").value;
  const loginPassword = document.getElementById("loginPassword").value;

  const savedEmail = localStorage.getItem("email");
  const savedPassword = localStorage.getItem("password");

  if (loginEmail === savedEmail && loginPassword === savedPassword) {
    alert("Login successful!");
  } else {
    alert("Invalid email or password");
  }
}
