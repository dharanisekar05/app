const apiUrl = "/api/users";

// Fetch and display users
async function getUsers() {
    const response = await fetch(apiUrl);
    const users = await response.json();

    const list = document.getElementById("userList");
    list.innerHTML = "";

    users.forEach(user => {
        const li = document.createElement("li");

        li.textContent = user.name + " ";

        const deleteBtn = document.createElement("button");
        deleteBtn.textContent = "Delete";
        deleteBtn.onclick = () => deleteUser(user.id);

        li.appendChild(deleteBtn);
        list.appendChild(li);
    });
}

// Add new user
async function addUser() {
    const input = document.getElementById("username");
    const name = input.value.trim();

    if (name === "") {
        alert("Please enter a name");
        return;
    }

    await fetch(apiUrl, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ name })
    });

    input.value = "";
    getUsers();
}

// Delete user
async function deleteUser(id) {
    await fetch(`${apiUrl}/${id}`, {
        method: "DELETE"
    });

    getUsers();
}

// Load users when page loads
getUsers();
